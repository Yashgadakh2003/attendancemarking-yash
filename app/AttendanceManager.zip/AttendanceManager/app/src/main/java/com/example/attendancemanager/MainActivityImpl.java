package com.example.attendancemanager;

public class MainActivityImpl extends MainActivity {
}
