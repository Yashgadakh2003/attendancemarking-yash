package com.example.attendancemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private Button btnMarkAttendance;
    private TextView tvAttendanceStatus;
    private RecyclerView recyclerView;
    private AttendanceAdapter adapter;
    private List<AttendanceRecord> attendanceList;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseApp.initializeApp(this);
        databaseReference = FirebaseDatabase.getInstance().getReference("attendance");

        initViews();
        setupRecyclerView();
        setupListeners();
        fetchAttendance();
    }

    private void initViews() {
        etName = findViewById(R.id.etName);
        btnMarkAttendance = findViewById(R.id.btnMarkAttendance);
        recyclerView = findViewById(R.id.recyclerViewAttendance);
        tvAttendanceStatus = findViewById(R.id.tvAttendanceStatus);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        attendanceList = new ArrayList<>();
        adapter = new AttendanceAdapter(attendanceList);
        recyclerView.setAdapter(adapter);
    }

    private void setupListeners() {
        btnMarkAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString().trim();
                if (!name.isEmpty()) {
                    markAttendance(name);
                    etName.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a student name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void fetchAttendance() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                attendanceList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    AttendanceRecord record = data.getValue(AttendanceRecord.class);
                    if (record != null) {
                        attendanceList.add(record);
                    }
                }
                adapter.notifyDataSetChanged();
                updateAttendanceStatusTextView();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Failed to load attendance: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void markAttendance(final String name) {
        final String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean alreadyMarked = false;

                for (DataSnapshot data : snapshot.getChildren()) {
                    AttendanceRecord record = data.getValue(AttendanceRecord.class);
                    if (record != null &&
                            record.getName().equalsIgnoreCase(name) &&
                            record.getDate().equals(currentDate)) {
                        alreadyMarked = true;
                        break;
                    }
                }

                if (alreadyMarked) {
                    Toast.makeText(MainActivity.this, "🕒 Attendance already marked for " + name + " today", Toast.LENGTH_SHORT).show();
                } else {
                    String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Calendar.getInstance().getTime());
                    String entryId = databaseReference.push().getKey();
                    AttendanceRecord record = new AttendanceRecord(name, currentDate, currentTime);

                    if (entryId != null) {
                        databaseReference.child(entryId).setValue(record)
                                .addOnSuccessListener(unused -> {
                                    Toast.makeText(MainActivity.this, "✅ Attendance marked for " + name, Toast.LENGTH_SHORT).show();
                                    fetchAttendance(); // Refresh the list
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(MainActivity.this, "❌ Failed to mark attendance: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                });
                    } else {
                        Toast.makeText(MainActivity.this, "❌ Could not generate ID", Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "❌ Firebase error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateAttendanceStatusTextView() {
        if (attendanceList != null && !attendanceList.isEmpty()) {
            AttendanceRecord last = attendanceList.get(attendanceList.size() - 1);
            tvAttendanceStatus.setText("Total Records: " + attendanceList.size() +
                    "\nLast Entry: " + last.getName() + " on " + last.getDate());
        } else {
            tvAttendanceStatus.setText("No attendance records yet.");
        }
    }
}
